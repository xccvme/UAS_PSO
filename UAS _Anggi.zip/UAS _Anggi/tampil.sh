dialog --title "Tiket Playground" --backtitle "Playground"  --msgbox " Nama Pengunjung : $na\n Jenis Tiket : $menuitem\n Hari Kunjungan: $hari\n Jumlah Tiket : $jmlh \n Tanggal Pesan : `date`\n Harga Tiket : 90000 \n Total $jmlh * 90000 = `expr  $jmlh \* 90000`" 10 80 ; 
rm -f /tmp/input.$$
